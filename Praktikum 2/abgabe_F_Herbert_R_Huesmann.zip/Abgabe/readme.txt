Jedes Projekt muss das UDPModul kennen. 
Der Pfad zur zur druckenden Datei muss stimmen bzw. gwählt werden.
Der Glasfishserver Fehlt. 
Im Dashboard müssen die IP adressen von jedem Drucker-Server angegeben werden.

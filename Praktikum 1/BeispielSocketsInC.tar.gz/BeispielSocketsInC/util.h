#pragma once

/************************************************************************
 *
 * Utility functions to use with sockets
 *
 ************************************************************************/

/************************************************************************
 *
 * Read "n" bytes from a descriptor.
 * Use in place of read() when fd is a stream socket.
 */
extern int readn(int fd, char* ptr, int nbytes);

/************************************************************************
 *
 * Read a line from a descriptor.  Read the line one byte at a time,
 * looking for the newline.  We store the newline in the buffer,
 * then follow it with a null (the same as fgets(3)).
 * We return the number of characters up to, but not including,
 * the null (the same as strlen(3)).
 */
extern int readline(int fd,char* ptr, int maxlen);

/************************************************************************
 *
 * Write "n" bytes to a descriptor.
 * Use in place of write() when fd is a stream socket.
 */
extern int writen(int fd, char* ptr, int nbytes);

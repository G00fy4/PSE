Jedes Projekt muss das UDPModul kennen. 
Der Pfad zur zur druckenden Datei muss stimmen bzw. gwählt werden.
Der Glasfishserver Bibiliothek muss eingebunden weden.
Die Bibiliothek org.eclipse.paho.client.mqttv3-1.0.2.jar im Ordner MQTT mus eingebunden werden.
Jeder MQ-Teilnehmer brauch eine eindeutige clientID.
